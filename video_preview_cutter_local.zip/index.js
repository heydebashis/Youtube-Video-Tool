import express from "express";
import cors from "cors";
import ytdl from "ytdl-core";
import ffmpegPath from "@ffmpeg-installer/ffmpeg";
import ffmpeg from "fluent-ffmpeg";
import path from "path";

const app = express();
app.use(cors());
app.use(express.static(path.join(process.cwd(), "public")));

// serve index.html at root
app.get("/", (req, res) => {
  res.sendFile(path.join(process.cwd(), "public", "index.html"));
});

ffmpeg.setFfmpegPath(ffmpegPath);

// parse "mm:ss" into total seconds
function parseTimestamp(ts) {
  const [m=0, s=0] = ts.split(":").map(Number);
  return m * 60 + s;
}

app.get("/cut", async (req, res) => {
  const { url, timestamp } = req.query;
  if (!url || !timestamp) {
    return res.status(400).send("Missing url or timestamp");
  }
  if (!ytdl.validateURL(url)) {
    return res.status(400).send("Only YouTube URLs supported");
  }

  const stream = ytdl(url, { quality: "highestvideo" });
  const startSec = parseTimestamp(timestamp);

  res.setHeader("Content-Type", "video/mp4");
  res.setHeader("Content-Disposition", 'attachment; filename="preview.mp4"');

  ffmpeg(stream)
    .setStartTime(startSec)
    .setDuration(4)
    .videoBitrate(1000)
    .noAudio()
    .format("mp4")
    .on("error", e => res.status(500).send("Encoding error"))
    .pipe(res, { end: true });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`🚀 Server listening on port ${PORT}`));
